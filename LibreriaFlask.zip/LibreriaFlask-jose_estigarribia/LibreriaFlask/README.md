# Libreria Personal utilizando Flask y sqlite

1- Crear entorno virtual con   python -m venv venv
2- Activar el entorno con   venv\Scripts\activate
3- instalar las dependencias con    pip install -r requirements.txt
4- Ir al archivo main.py y ejecutar
5- En la terminal que aparece: Running on http://127.0.0.1:5000/ (Press CTRL+C to quit), presionar CTRL y sin soltar dar click sobre la dirección http.
6- Se abrirá una instancia en el navegador con el programa ejecutándose.
7- Para el login, el usuario admin es:
    -Correo: estigarribiajose064@gmail.com
    -Contraseña: password
