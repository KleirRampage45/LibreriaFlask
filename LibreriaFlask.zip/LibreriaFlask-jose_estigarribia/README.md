# Libreria Personal utilizando Flask y sqlite

Utilizando el framework web de Flask, y la base de datos SQLite, el sistema de control de la libreria se crea. Se necesita una base de datos para guardar los libros y que no se pierdan al reiniciar el servidor.
